# Discord - SelfBot is a Script for discord account bot written in Python.

### This SelfBot has a total of about 60 commands to make your life on discord easier. It has a nice and intuitive interface to make it easy to use for everyone, help and explanations for each command, a very complete help command.

## Disclaimer

|SelfBot was made for Educational purposes|
|-------------------------------------------------|
This project was created only for good purposes and personal use.
By using this SelfBot, you agree that you hold responsibility and accountability of any consequences caused by your actions.

## ( HOW TO SETUP/START )

- INSTALL PYTHON 
- FILL YOUR TOKEN IN CONFIG & STATUS ROTATOR (you can open it by a right click) AT `"authorization" : ""`
- RUN THE FILE WITH NAME "RunApp.bat"

## ENJOY !

## HOW TO OVERCOME ERROR ?

To overcome any error or problem or any query you can contact me on insta(alcoholic.xd) or on discord(https://discord.gg/r47SxUuRSR)

### TYPE HELP ON DISCORD TO SEE FEATURES OF YOU BOT...

# ][ PROJECT FINALLY COMPLETED ON 13.6.23 ][
